package voterRegistration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class VoterRegisterDB {
	
	
	private String databaseName="";
	private String dburl = "jdbc:mysql://localhost:3306/" +databaseName;
	
	private String dbuname="root";
	private String dbpassword= "qwerty";
	private String dbdriver = "com.mysql.cj.jdbc.Driver";
	
	public void loadDriver(String dbDriver)
	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(dburl, dbuname, dbpassword);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public String insert(SetUserDetails setUserDetails){
		loadDriver(dbdriver);
		Connection con = getConnection();
		String sql = "insert into reg.userdetails(Password,FirstName,LastName,DOB,Age,Gender,"
				+ "Address,PhoneNo,Constituency,District) values(?,?,?,?,?,?,?,?,?,?)";
		
		String result=("Registration Successfully");
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, setUserDetails.getPassword());
			ps.setString(2, setUserDetails.getFirstName());
			ps.setString(3, setUserDetails.getLastName());
			ps.setString(4, setUserDetails.getDob());
			ps.setInt(5, setUserDetails.getAge());
			ps.setString(6, setUserDetails.getGender());
			ps.setString(7, setUserDetails.getAddress());
			ps.setString(8, setUserDetails.getPhoneno());
			ps.setString(9, setUserDetails.getConstituency());
			ps.setString(10, setUserDetails.getDistrict());
			ps.executeUpdate();
					
		} catch (SQLException e) {

			result="Data Not Entered Successfully";
			e.printStackTrace();
		}
		return result;
}
}

