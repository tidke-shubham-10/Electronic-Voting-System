package voterRegistration;

public class SetUserDetails {
	private String firstName,lastName,dob,gender,password,address,phoneno,district,constituency;
	private int age,UserID;

	public SetUserDetails() {
		super();
	}
	
	public SetUserDetails(int userID) {
		super();
		this.UserID = userID;
	}
	
	public SetUserDetails(int userID, String password) {
		super();
		this.UserID = userID;
		this.password = password;
	}

	public SetUserDetails(String firstName, String lastName, String dob, int age,String gender, String password, String address
			 ,String phoneno, String district,String constituency) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
		this.age = age;
		this.gender = gender;
		this.password = password;
		this.address = address;
		this.phoneno = phoneno;
		this.district = district;
		this.constituency = constituency;
		
	}
	
	public int getUserID() {
		return UserID;
	}

	public void setUserID(int userID) {
		this.UserID = userID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public String getConstituency() {
		return constituency;
	}

	public void setConstituency(String constituency) {
		this.constituency = constituency;
	}
	
	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

}
