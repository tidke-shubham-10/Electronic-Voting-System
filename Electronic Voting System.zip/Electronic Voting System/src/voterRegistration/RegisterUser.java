package voterRegistration;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/RegisterUser")
public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
    public RegisterUser() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String dob=request.getParameter("dob");
		int age=Integer.parseInt(request.getParameter("age"));
		String gender=request.getParameter("gender");
		String password=request.getParameter("password");
		String address=request.getParameter("address");
		String phoneno=request.getParameter("phoneno");
		String district=request.getParameter("district");
		String constituency=request.getParameter("constituency");
		
		SetUserDetails setUserDetails = new SetUserDetails(fname, lname, dob, age, gender, password, address, phoneno, district, constituency);
		VoterRegisterDB registerDB=new VoterRegisterDB();
		String result = registerDB.insert(setUserDetails);
		response.getWriter().println(result);

		if(result.equals("Registration Successfully")) {
			request.getRequestDispatcher("/RetriveUserID.jsp").forward(request, response);
		}
	}
}

