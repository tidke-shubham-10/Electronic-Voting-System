package userLogin;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.FileWriter;
 
@WebServlet("/SendToCheckLoginUserID")
public class SendToCheckLoginUserID extends HttpServlet {
private static final long serialVersionUID = 1L;
 
public SendToCheckLoginUserID() {
}
 
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{
request.getParameter("userID");
request.getParameter("password");

String userID = request.getParameter("userID");

    FileWriter myWriter = new FileWriter("C:\\Users\\prawa\\Desktop\\Electronic Voting System\\Sample.txt");
    myWriter.write(userID);
    myWriter.close();

    request.getRequestDispatcher("/CheckLoginUserID.jsp").forward(request, response);
 
} 
}