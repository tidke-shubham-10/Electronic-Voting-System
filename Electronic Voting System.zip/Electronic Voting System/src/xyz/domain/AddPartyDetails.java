package xyz.domain;

public class AddPartyDetails {
	private String pName,lName, logo;

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getlogo() {
		return logo;
	}

	public void setlogo(String logo) {
		this.logo = logo;
	}

	
}
