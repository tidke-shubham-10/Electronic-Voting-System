package xyz.domain;

public class RegisterAdmin {
	private String canName,canDOB,electionName,partyName,district,constituency, address, phoneNum, emailID;

	public RegisterAdmin() {
		
	}

	public String getcanDOB() {
		return canDOB;
	}

	public void setcanDOB(String canDOB) {
		this.canDOB = canDOB;
	}

	public String getcanName() {
		return canName;
	}

	public void setcanName(String canName) {
		this.canName = canName;
	}

	public String getelectionName() {
		return electionName;
	}

	public void setelectionName(String electionName) {
		this.electionName = electionName;
	}

	public String getpartyName() {
		return partyName;
	}

	public void setpartyName(String partyName) {
		this.partyName = partyName;
	}
	
	public String getaddress() {
		return address;
	}

	public void setaddress(String address) {
		this.address = address;
	}
	
	public String getconstituency() {
		return constituency;
	}

	public void setconstituency(String constituency) {
		this.constituency = constituency;
	}
	
	public String getphoneNum() {
		return phoneNum;
	}

	public void setphoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	
	public String getemailID() {
		return emailID;
	}

	public void setemailID(String emailID) {
		this.emailID = emailID;
	}
	
	public String getdistrict() {
		return district;
	}

	public void setdistrict(String district) {
		this.district = district;
	}

}
