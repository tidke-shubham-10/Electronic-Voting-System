package xyz.domain;

public class AddElecDetails {
	private String eName,eDate,votingtime,district,constituency;

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public String geteDate() {
		return eDate;
	}

	public void seteDate(String eDate) {
		this.eDate = eDate;
	}

	public String getVotingtime() {
		return votingtime;
	}

	public void setVotingtime(String votingtime) {
		this.votingtime = votingtime;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getConstituency() {
		return constituency;
	}

	public void setConstituency(String constituency) {
		this.constituency = constituency;
	}

}