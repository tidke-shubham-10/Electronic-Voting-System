package xyz.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import xyz.domain.AddPartyDetails;


public class PartyBin {
	
	private static String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	static private Connection courseDbConn;
	static String databaseName="";
	static String url = "jdbc:mysql://localhost:3306/" +databaseName;
	
	static String username="root";
	static String password= "qwerty";
	

	public static Connection getConnection() throws SQLException {
		if (courseDbConn == null) {   									/*SETTING CONNECTION */
			courseDbConn = DriverManager.getConnection(url, username, password);
		}

		return courseDbConn;
	}

	public static void shutdown() throws SQLException {
		if (courseDbConn != null) {
			courseDbConn.close();
		}
	}
	
	
/****ALREADY REGISTERED PARTY DETAILS *****/	
	
	public int loginCheck(AddPartyDetails add) throws SQLException,
			ClassNotFoundException {
		Class.forName(JDBC_DRIVER);
		Connection connection;
		connection = getConnection();
		int count;
	String queryStr = "select count(*) from admin.Pdetails where pName = '"
				+ add.getpName() + "' and logo = '" + add.getlogo()
				+ "';";
		Statement queryStmt = connection.createStatement();
		ResultSet result;
		result = queryStmt.executeQuery(queryStr);
		result.next();
		count = result.getInt(1);
		result.close();
		queryStmt.close();
		return count;
	}
	
	
    public void AddParty(AddPartyDetails add) throws SQLException,
	ClassNotFoundException {
    	
    	Class.forName(JDBC_DRIVER);
		Connection connection;
		connection = getConnection();

		String queryStr1 = "insert into admin.Pdetails (pName,lName,logo ) values (?,?,?);";
		try {
			PreparedStatement ps = connection.prepareStatement(queryStr1);
			ps.setString(1, add.getpName());
			ps.setNString(2, add.getlName());
			
			ps.setString(3, add.getlogo());

			
			ps.executeUpdate();
		} catch (Exception e) {
		}
    	
    	}
		
}
