package xyz.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//import xyz.domain.Register;
//import xyz.database.ElectBin;
import xyz.domain.AddElecDetails;

public class ElectBin {
	
	private static String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	static private Connection courseDbConn;
	static String databaseName="";
	static String url = "jdbc:mysql://localhost:3306/" +databaseName;
	
	static String username="root";
	static String password= "qwerty";
	

	public static Connection getConnection() throws SQLException {
		if (courseDbConn == null) {   									/*SETTING CONNECTION */
			courseDbConn = DriverManager.getConnection(url, username, password);
		}

		return courseDbConn;
	}

	public static void shutdown() throws SQLException {
		if (courseDbConn != null) {
			courseDbConn.close();
		}
	}
	
	
	
/****ALREADY REGISTERED ELECTION DETAILS *****/	
	
	public int loginCheck(AddElecDetails ele) throws SQLException,
			ClassNotFoundException {
		Class.forName(JDBC_DRIVER);
		Connection connection;
		connection = getConnection();
		int count;
	String queryStr = "select count(*) from admin.Edetails where eName = '"
				+ ele.geteName() + "' and Constituency = '" + ele.getConstituency()
				+ "';";
		Statement queryStmt = connection.createStatement();
		ResultSet result;
		result = queryStmt.executeQuery(queryStr);
		result.next();
		count = result.getInt(1);
		result.close();
		queryStmt.close();
		return count;
	}
	
	
    public void AddElecDetail(AddElecDetails add) throws SQLException,
	ClassNotFoundException {
    	
    	Class.forName(JDBC_DRIVER);
		Connection connection;
		connection = getConnection();

		String queryStr1 = "insert into admin.Edetails (eName,eDate,district,constituency) values (?,?,?,?);";
		try {
			PreparedStatement ps = connection.prepareStatement(queryStr1);
			ps.setString(1, add.geteName());
			ps.setNString(2, add.geteDate());
//			ps.setString(5, add.getVotingtime());
			ps.setString(3, add.getDistrict());
			ps.setString(4, add.getConstituency());
			
			ps.executeUpdate();
		} catch (Exception e) {
		}
		
    	
    	
    	}
}
