package xyz.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import xyz.domain.LoginDomain;


public class LoginBin {
	
	private static String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	static private Connection courseDbConn;
	static String databaseName="";
	static String url = "jdbc:mysql://localhost:3306/" +databaseName;
	
	static String username="root";
	static String password= "qwerty";
	

	public static Connection getConnection() throws SQLException {
		if (courseDbConn == null) {   									/*SETTING CONNECTION */
			courseDbConn = DriverManager.getConnection(url, username, password);
		}

		return courseDbConn;
	}

	public static void shutdown() throws SQLException {
		if (courseDbConn != null) {
			courseDbConn.close();
		}
	}
	
	public int loginCheck(LoginDomain lod) throws SQLException,
	ClassNotFoundException {
		Class.forName(JDBC_DRIVER);
		Connection connection;
		connection = getConnection();
		int count;
		
		String queryStr = "select count(*) from admin.admin where username = '"
				+ lod.getusername() + "' and Password = '" + lod.getpassword()
				+ "';";
		Statement queryStmt = connection.createStatement();
		ResultSet result;
		result = queryStmt.executeQuery(queryStr);
		result.next();
		count = result.getInt(1);
		result.close();
		queryStmt.close();
		return count;
	}
}
