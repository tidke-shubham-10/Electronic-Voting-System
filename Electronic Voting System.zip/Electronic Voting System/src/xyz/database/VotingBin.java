package xyz.database;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import xyz.domain.RegisterAdmin;


public class VotingBin {

	
	

	
	private static String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	static private Connection courseDbConn;
	static String databaseName="";
	static String url = "jdbc:mysql://localhost:3306/" +databaseName;
	
	static String username="root";
	static String password= "qwerty";
	

	public static Connection getConnection() throws SQLException {
		if (courseDbConn == null) {   									/*SETTING CONNECTION */
			courseDbConn = DriverManager.getConnection(url, username, password);
		}

		return courseDbConn;
	}

	public static void shutdown() throws SQLException {
		if (courseDbConn != null) {
			courseDbConn.close();
		}
	}

/****ALREADY REG *****/	
	
	public int loginCheck(RegisterAdmin reg) throws SQLException,
			ClassNotFoundException {
		Class.forName(JDBC_DRIVER);
		Connection connection;
		connection = getConnection();
		int count;
	String queryStr = "select count(*) from admin.cdetails where canName = '"
				+ reg.getcanName() + "' and emailID = '" + reg.getemailID()
				+ "';";
		Statement queryStmt = connection.createStatement();
		ResultSet result;
		result = queryStmt.executeQuery(queryStr);
		result.next();
		count = result.getInt(1);
		result.close();
		queryStmt.close();
		return count;
	}
	

	
	

/*LOGIN REGIsTER*/	public void loginRegistration(RegisterAdmin reg) throws SQLException,
			ClassNotFoundException {
		Class.forName(JDBC_DRIVER);
		Connection connection;
		connection = getConnection();

		String queryStr1 = "insert into admin.cdetails (canName,canDOB,electionName,partyName,district,constituency, address, phoneNum, emailID) values (?,?,?,?,?,?,?,?,?);";
		try {
			PreparedStatement ps = connection.prepareStatement(queryStr1);
			ps.setString(1, reg.getcanName());
			ps.setNString(2, reg.getcanDOB());
			ps.setString(3, reg.getelectionName());
			ps.setString(4, reg.getpartyName());
			ps.setString(5, reg.getdistrict());
			ps.setString(6, reg.getconstituency());
			ps.setString(7, reg.getaddress());
			ps.setNString(8, reg.getphoneNum());
			ps.setString(9, reg.getemailID());
			ps.executeUpdate();
		} catch (Exception e) {
		}
	} 

}
