package xyz.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import java.sql.SQLException;


import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import xyz.database.ElectBin;

import xyz.domain.*;



@WebServlet("/AddElecDetails")
public class AddElectionDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public AddElectionDetails() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		AddElecDetails add = new AddElecDetails();
		ElectBin vb = new ElectBin();
		
		int count=0;
		
		add.seteName(request.getParameter("eName"));
		add.seteDate(request.getParameter("eDate"));
		add.setVotingtime(request.getParameter("votingtime"));
		add.setConstituency(request.getParameter("constituency"));
		
		add.setDistrict(request.getParameter("district"));
		
		synchronized(vb) {
			try {
				vb.loginCheck(add);
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(count==0) {
			try {
				vb.AddElecDetail(add);
				PrintWriter out = response.getWriter();
				out.println("<script>alert(\"Election Details Filled !\");</script>");
				RequestDispatcher rd = getServletContext().getRequestDispatcher("/admin.jsp");
				rd.include(request, response);
			}
			 catch (Exception e) {
				e.printStackTrace();
			}
		}
			
			
		else {
			PrintWriter out = response.getWriter();
			out.println("<script>alert(\"Registration Unsuccessful !!! Data Already Exist !!!\");</script>");
			
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.jsp");
			
			rd.include(request, response);
		}
	}
}

