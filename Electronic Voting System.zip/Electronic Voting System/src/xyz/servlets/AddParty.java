package xyz.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import java.sql.SQLException;


import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import xyz.database.PartyBin;

import xyz.domain.*;



@WebServlet("/AddPartyDetails")
public class AddParty extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public AddParty() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		AddPartyDetails add = new AddPartyDetails();
		PartyBin vb = new PartyBin();
		
		int count=0;
		
		add.setpName(request.getParameter("pName"));
		add.setlName(request.getParameter("lName"));
		add.setlogo(request.getParameter("logo"));
		
		synchronized(vb) {
			try {
				vb.loginCheck(add);
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(count==0) {
			try {
				vb.AddParty(add);
				PrintWriter out = response.getWriter();
				out.println("<script>alert(\"Party Details Filled !\");</script>");
				RequestDispatcher rd = getServletContext().getRequestDispatcher("/admin.jsp");
				rd.include(request, response);
			}
			 catch (Exception e) {
				e.printStackTrace();
			}
		}
			
			
		else {
			PrintWriter out = response.getWriter();
			out.println("<script>alert(\"Registration Unsuccessful !!! Data Already Exist !!!\");</script>");
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.jsp");
			
			rd.include(request, response);
		}
	}
}

