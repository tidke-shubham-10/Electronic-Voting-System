package xyz.servlets;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;



@WebServlet("/SendToCheckAdminLogin")
public class SendToCheckAdminLogin extends HttpServlet {
private static final long serialVersionUID = 1L;
 
public SendToCheckAdminLogin() {
}
 
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{
request.getParameter("username");
request.getParameter("password");
 
    request.getRequestDispatcher("/CheckAdminLogin.jsp").forward(request, response);
 
} 
}
