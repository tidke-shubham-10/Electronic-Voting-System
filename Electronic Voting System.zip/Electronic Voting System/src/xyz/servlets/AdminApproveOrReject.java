package xyz.servlets;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/AdminApproveOrReject")
public class AdminApproveOrReject extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public AdminApproveOrReject() {
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getParameter("approve");
		request.getParameter("reject");
	
	
		    request.getRequestDispatcher("/AdminSendVoterIDToUser.jsp").forward(request, response);
	}
}