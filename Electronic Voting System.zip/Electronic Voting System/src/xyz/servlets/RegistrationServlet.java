package xyz.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import xyz.database.VotingBin;
import xyz.domain.RegisterAdmin;


@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RegisterAdmin reg = new RegisterAdmin();
		VotingBin vb = new VotingBin();
		int count=0;
		
		reg.setcanName(request.getParameter("canName"));
		reg.setcanDOB(request.getParameter("canDOB"));
		reg.setelectionName(request.getParameter("electionName"));
		reg.setpartyName(request.getParameter("partyName"));
		
		reg.setdistrict(request.getParameter("district"));
		reg.setconstituency(request.getParameter("constituency"));
		reg.setaddress(request.getParameter("address"));
		reg.setphoneNum(request.getParameter("phoneNum"));
		reg.setemailID(request.getParameter("emailID"));
		
		synchronized(vb) {
			try {
				count = vb.loginCheck(reg);
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(count==0) {
			try {
				vb.loginRegistration(reg);
				PrintWriter out = response.getWriter();
				out.println("<script>alert(\"Registration done!\");</script>");
				RequestDispatcher rd = getServletContext().getRequestDispatcher("/admin.jsp");
				rd.include(request, response);
			}
			 catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		}
			
			
		else {
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.jsp");
			PrintWriter out = response.getWriter();
			out.println("<script>alert(\"Registration Unsuccessful !!! Data Already Exist !!!\");</script>");
			rd.include(request, response);
		}
	}
}
